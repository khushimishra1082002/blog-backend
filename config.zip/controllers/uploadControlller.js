const express = require("express");
const multer = require("multer");
const path = require("path");

// Setup multer staorage configration

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./uploads");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({ storage: storage });

const uploadPostImage = (req, res) => {
  try {
    if (!req.file) {
      return res.status(200).json({ message: "No file uploaded" });
    }
    res
      .status(200)
      .json({ message: "File uploaded successfully", file: req.file });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const uploadProfileImage = (req, res) => {
  try {
    if (!req.file) {
      return res.status(200).json({ message: "No file uploaded" });
    }
    res
      .status(200)
      .json({ message: "File uploaded successfully", file: req.file });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  uploadPostImage,
  uploadProfileImage,
  upload,
};
