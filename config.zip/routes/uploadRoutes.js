const express = require("express");
const router = express.Router();
const { uploadPostImage, upload, uploadProfileImage } = require("../controllers/uploadController");
const { authenticate, authorize } = require("../middlewares/authMiddleware");

router.post("/uploadPostImage", authenticate, authorize(["admin", "editor"]), upload.single('file'), uploadPostImage);

router.post("/uploadProfileImage", authenticate, upload.single('file'), uploadProfileImage);

module.exports = router;
