const express = require("express")
const router = express.Router()
const {getUsers,getSingleUser,createUser,updateUser,deleteUser} = require("../controllers/userControllers")
const {authenticate,authorize} =  require("../middlewares/authMiddleware")

router.get("/getUsers", authenticate,authorize(["admin"]),getUsers)
router.get("/getSingleUser/:id", authenticate,authorize(["admin"]),getSingleUser)
router.post("/createUser", authenticate,authorize(["admin"]),createUser)
router.put("/updateUser/:id", authenticate,authorize(["admin"]),updateUser)
router.delete("/deleteUser/:id", authenticate,authorize(["admin"]),deleteUser)

module.exports = router;

